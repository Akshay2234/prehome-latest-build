// config.js
export const BASE_API_URL = 'https://prehome.payzmall.com/api';