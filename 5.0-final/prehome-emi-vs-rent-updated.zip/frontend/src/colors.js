// src/colors.js
const colors = {
    primary: '#FFFFFF', // White
    secondary: '#0000FF', // Blue
    red: '#FF0000', // Red
    grey: '#808080', // Grey
    black: '#000000' // Black
  };
  
  export default colors;
  